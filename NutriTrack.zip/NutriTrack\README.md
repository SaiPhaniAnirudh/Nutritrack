# 🥗 NutriTrack

> **AI-powered food nutrition tracker** — scan any meal photo and get instant macros, calories, and diet tips.

![NutriTrack](https://img.shields.io/badge/AI-Qwen2--VL--7B-brightgreen) ![Flask](https://img.shields.io/badge/Backend-Flask-blue) ![PWA](https://img.shields.io/badge/PWA-ready-purple) ![No API Key](https://img.shields.io/badge/AI-No%20API%20Key%20Required-orange)

---

## ✨ Features

- 📸 **Snap & Scan** — point your camera at any food, get nutrition in seconds
- 🤖 **85–90% accuracy** — Qwen2-VL-7B (7B parameter vision model) runs locally
- 🍛 **Indian cuisine specialist** — biryani, dosa, dal, paratha and 80+ more foods in the built-in database
- 🧮 **Full macros** — calories, protein, carbs, fat, fiber, sugar, sodium, cholesterol
- 📊 **30-day history** — daily totals, streak tracking, visual progress
- 🔒 **JWT auth** — register / login, multi-device sync
- 📱 **PWA** — install on your phone, works offline after first load
- 🌐 **Zero API key required** — AI runs 100% locally via Ollama

---

## 🏗️ Architecture

```
Browser / PWA
     │
     ▼
App.py (Flask REST API — port 5000)
     │
     ├─ Auth, food logs, analytics (SQLite / PostgreSQL)
     │
     └─▶ Llm_server.py (AI proxy — port 5002)
               │
               ├─ Engine 1: Groq Cloud      (2-3 s, needs GROQ_API_KEY)
               ├─ Engine 2: Ollama/Qwen2-VL (6-8 s CPU / <2 s GPU) ← DEFAULT
               └─ Engine 3: Moondream2      (25 s CPU, fallback only)
```

### Engine Priority (auto mode)

| Engine | Speed | Accuracy | API Key | Internet |
|---|---|---|---|---|
| **Groq Cloud** | 2–3 s | ~88% | ✅ GROQ_API_KEY | Required |
| **Ollama / Qwen2-VL-7B** | 6–8 s CPU / <2 s GPU | **85–90%** | ❌ None | First pull only |
| Moondream2 | 20–30 s CPU | ~60–65% | ❌ None | First pull only |

> **Recommended**: Ollama + Qwen2-VL-7B. Fast, accurate, completely free, works offline.

---

## 🚀 Quick Start (Local — No Docker)

### Prerequisites

- Python 3.10+
- [Ollama](https://ollama.com/download) installed

### Windows

```bat
REM 1. Clone / download the project
REM 2. Run the setup script (one time):
setup.bat

REM 3. Start Ollama (if not already running):
ollama serve

REM 4. Open two more terminals and activate the venv:
.venv\Scripts\activate.bat

REM Terminal A — AI server:
python Llm_server.py

REM Terminal B — Flask API:
python App.py
```

Then open **http://localhost:5000** in your browser.

### macOS / Linux

```bash
# 1. Clone the project
git clone https://github.com/your-user/nutritrack.git
cd nutritrack

# 2. One-time setup
chmod +x setup.sh && ./setup.sh

# 3. Start everything (3 terminals)
ollama serve                          # Terminal 1
source .venv/bin/activate && python Llm_server.py   # Terminal 2
source .venv/bin/activate && python App.py          # Terminal 3
```

Open **http://localhost:5000**.

---

## 🐳 Docker (One Command)

```bash
# Start the entire stack (Ollama + AI server + Flask API)
docker compose up -d

# Watch logs
docker compose logs -f

# Stop
docker compose down
```

> **First run**: Docker will automatically pull the Qwen2-VL-7B model (~5 GB). This is a one-time download. After that, everything works offline.

Open **http://localhost:5000**.

### GPU acceleration (NVIDIA)

Uncomment the `deploy` block in `docker-compose.yml` to enable CUDA. Inference drops from ~8 s → ~1.5 s.

---

## ⚙️ Configuration

Copy `.env.example` to `.env` and edit as needed:

```env
# Required
JWT_SECRET_KEY=your-long-random-secret

# Optional — Groq Cloud (makes AI faster, 2-3 s instead of 6-8 s)
GROQ_API_KEY=gsk_...

# Optional — USDA food database (300k+ foods)
USDA_API_KEY=...

# Optional — Ollama settings
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=qwen2-vl:7b

# Optional — production database
DATABASE_URL=postgresql://user:pass@host:5432/nutritrack
```

---

## 🛠️ Manual Model Setup (Ollama)

```bash
# Install Ollama
# macOS:   brew install ollama
# Linux:   curl -fsSL https://ollama.com/install.sh | sh
# Windows: https://ollama.com/download

# Pull the model (5 GB, one time)
ollama pull qwen2-vl:7b

# Verify it's running
ollama list
curl http://localhost:11434/api/tags
```

### Alternative smaller models

If you have limited RAM (< 8 GB), use a quantized version:

```bash
ollama pull qwen2-vl:7b-instruct-q4_K_M   # ~4.5 GB, slightly lower accuracy
ollama pull qwen2-vl:2b                    # ~1.5 GB, faster but less accurate
```

Set `OLLAMA_MODEL=qwen2-vl:2b` in `.env` if using the 2B variant.

---

## 📡 API Reference

### AI Analysis

```http
POST /api/ai/analyze
Content-Type: application/json

{ "image": "data:image/jpeg;base64,..." }
```

**Response:**
```json
{
  "description": "2 foods: Chicken Biryani, Raita",
  "items": [
    {
      "food_name": "Chicken Biryani",
      "calories": 350,
      "protein_g": 15,
      "carbs_g": 48,
      "fat_g": 12,
      "fiber_g": 2,
      "sugar_g": 3,
      "sodium_mg": 480,
      "cholesterol_mg": 45,
      "serving_size": "1 plate (300g)",
      "confidence": 88
    }
  ],
  "tips": "High calorie — pair with raita for balance.",
  "_meta": { "model": "Ollama/qwen2-vl:7b", "mode": "local_llm", "latency_ms": 6200 }
}
```

### Auth

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Login → JWT |
| POST | `/api/auth/refresh` | Refresh access token |
| GET  | `/api/auth/me` | Current user profile |
| PUT  | `/api/auth/update` | Update profile / goals |

### Food Logs

| Method | Endpoint | Description |
|---|---|---|
| GET    | `/api/logs` | Get logs (`?date=YYYY-MM-DD` or `?days=30`) |
| POST   | `/api/logs` | Add food log entry |
| DELETE | `/api/logs/<id>` | Remove log entry |
| GET    | `/api/logs/summary` | Daily totals for past N days |
| GET    | `/api/analytics/streak` | Consecutive logging streak |

---

## 📁 File Structure

```
nutritrack/
├── App.py              ← Flask REST API (auth, logs, AI proxy)
├── Llm_server.py       ← AI inference server (Ollama / Groq / Moondream)
├── Database.py         ← DB helpers
├── index.html          ← PWA frontend shell
├── App.js              ← Frontend logic
├── Style.css           ← UI styles
├── Foods.js            ← Local food database (offline fallback)
├── sw.js               ← Service worker (PWA offline support)
├── manifest.json       ← PWA manifest
│
├── requirements.txt    ← Python dependencies
├── .env.example        ← Environment variable template
├── .env                ← Your local config (not in git)
│
├── docker-compose.yml  ← Full stack: Ollama + LLM + API
├── Dockerfile.llm      ← AI server container
├── Dockerfile.api      ← Flask API container
│
├── setup.bat           ← Windows first-run setup
└── setup.sh            ← macOS/Linux first-run setup
```

---

## 🚢 Deployment (Render / Railway / VPS)

### Option A — Docker (recommended)

Push to any VPS with Docker installed:

```bash
docker compose up -d
```

> Set `DATABASE_URL` to a PostgreSQL connection string for production.

### Option B — Render.com (free tier)

1. Connect your GitHub repo to Render
2. Create two **Web Services**:
   - `App.py` → Python runtime, `python App.py`, port 5000
   - `Llm_server.py` → Python runtime, `python Llm_server.py`, port 5002
3. Add environment variables in Render dashboard
4. Set `LLM_SERVER_URL=https://your-llm-service.onrender.com` in the API service

> On Render free tier, use `GROQ_API_KEY` instead of Ollama (Ollama needs persistent storage for model weights).

---

## 🧠 Why Qwen2-VL-7B?

| Model | Params | Food Accuracy | Speed (CPU) | API Key |
|---|---|---|---|---|
| Moondream2 | 1.8B | ~60% | 25–30 s | ❌ |
| **Qwen2-VL-7B** | **7B** | **85–90%** | **6–8 s** | **❌** |
| LLaVA-13B | 13B | ~82% | 40–60 s | ❌ |
| GPT-4o | — | ~95% | 1–2 s | ✅ Paid |
| Groq/Llama-4-Scout | — | ~88% | 2–3 s | ✅ Free |

Qwen2-VL-7B hits the sweet spot: **no API key**, **5× faster than Moondream**, **25–30% better accuracy**, and runs on any consumer GPU or modern CPU.

---

## 📜 License

MIT — free to use, modify, and deploy.
