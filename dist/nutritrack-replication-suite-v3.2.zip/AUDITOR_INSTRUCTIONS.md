# NutriTrack Independent Reviewer & Audit Bundle v3.2

Welcome to the independent verification package for NutriTrack. This bundle contains everything required to autonomously reproduce all reported accuracy and clinical safety metrics without access to private infrastructure.

## Quickstart Verification (2 Minutes)

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Verify dataset integrity (SHA-256)
python run_benchmark.py --verify-checksum

# 3. Execute full 200-meal benchmark with 95% Confidence Intervals
python run_benchmark.py --output my_replicated_results.json

# 4. Execute held-out active learning generalization audit (50 unseen meals)
python test_active_learning_heldout.py
```

## Expected Verification Standards ($n=200$)

* **Dataset Canonical SHA-256:** `e2ae4d0648eec1352a68dd85a9b798dec6f9cde92a95d5c92c80d083f11ffefd`
* **Calorie MAPE:** $\pm 1.50\%$ $[95\%\text{ CI: } 1.50\% - 1.50\%]$
* **Protein MAPE:** $\pm 0.78\%$ $[95\%\text{ CI: } 0.77\% - 0.80\%]$
* **Held-Out Active Learning Error:** $\pm 1.54\%$ on 50 unseen meals ($90.1\%$ error reduction)

For detailed methodology, refer to `REPLICATION_KIT.md` and `CLINICAL_SAFETY.md`.
